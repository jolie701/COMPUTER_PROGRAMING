#ifndef SNAKEGAME_H
#define SNAKEGAME_H
#include <vector>

class SnakeGame {
public:
	enum Direction {
		UP, DOWN, LEFT, RIGHT
	};
	enum Direction2 {
		 W, A, S, D
	};
private:
	struct SingleNodeSnake {
		int x;
		int y;

	};//�D���W���@�`

	std::vector <SingleNodeSnake> nodesnake1;
	//�Ф@�ӥsnodesnake1��vector�A�x�s���struct
	std::vector <SingleNodeSnake> nodesnake2;
	SingleNodeSnake newHead;
	int  X, Y;
	int leng;
	
public:
	SnakeGame();//constructor
	
	void snakebody(int, int, int, int, int);
	void move();//move�i�H��������private��vector�A�N���ΦA�ǰѼ�
	int getX()const;
	int getY()const;
	SingleNodeSnake getHead()const;
	SingleNodeSnake getTail()const;
	SingleNodeSnake getHead2()const;
	SingleNodeSnake getTail2()const;
	size_t Size1()const;
	size_t Size2()const;
	
	bool terminated;//�Ω�C���j��(�w�q�bpublic��)
	Direction dir;
	Direction2 dir2;
	void collidingWithWall();
	void collidingWithOther();
	void play();
	void generateFood();

};

#endif

